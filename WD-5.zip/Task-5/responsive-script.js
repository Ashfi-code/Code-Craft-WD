/**
 * Responsive Weather App JavaScript
 * Features: Geolocation, Weather API, Responsive Design, Error Handling
 */

// Configuration
const CONFIG = {
    API_KEY: '8c5c5f95e92f4c1aaf3123456789abcd', // Replace with your OpenWeatherMap API key
    BASE_URL: 'https://api.openweathermap.org/data/2.5',
    UNITS: 'metric',
    DEMO_MODE: true // Set to false for production
};

// Weather icon mapping
const WEATHER_ICONS = {
    'clear sky': '☀️',
    'few clouds': '🌤️',
    'scattered clouds': '⛅',
    'broken clouds': '☁️',
    'overcast clouds': '☁️',
    'light rain': '🌦️',
    'moderate rain': '🌧️',
    'heavy rain': '⛈️',
    'shower rain': '🌦️',
    'rain': '🌧️',
    'thunderstorm': '⛈️',
    'thunderstorm with light rain': '⛈️',
    'thunderstorm with rain': '⛈️',
    'thunderstorm with heavy rain': '⛈️',
    'light snow': '🌨️',
    'snow': '❄️',
    'heavy snow': '❄️',
    'sleet': '🌨️',
    'mist': '🌫️',
    'fog': '🌫️',
    'haze': '🌫️',
    'smoke': '🌫️',
    'dust': '🌫️',
    'sand': '🌫️'
};

// Detail icons mapping
const DETAIL_ICONS = {
    humidity: '💧',
    wind: '💨',
    pressure: '🌡️',
    visibility: '👁️'
};

// Global variables
let currentWeatherData = null;
let favoriteCities = [];

// DOM Elements
const elements = {
    weatherContainer: null,
    cityInput: null,
    locationBtn: null,
    searchBtn: null,
    menuBtn: null,
    closeMenu: null,
    sideMenu: null,
    overlay: null
};

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

/**
 * Initialize the application
 */
function initializeApp() {
    // Get DOM elements
    elements.weatherContainer = document.getElementById('weatherContainer');
    elements.cityInput = document.getElementById('cityInput');
    elements.locationBtn = document.getElementById('locationBtn');
    elements.searchBtn = document.getElementById('searchBtn');
    elements.menuBtn = document.getElementById('menuBtn');
    elements.closeMenu = document.getElementById('closeMenu');
    elements.sideMenu = document.getElementById('sideMenu');
    elements.overlay = document.getElementById('overlay');
    
    // Load saved favorites
    loadFavorites();
    
    // Set up event listeners
    setupEventListeners();
    
    // Add interactive effects
    addInteractiveEffects();
    
    // Initialize with current location
    getCurrentLocation();
}

/**
 * Set up all event listeners
 */
function setupEventListeners() {
    // Search functionality
    elements.cityInput.addEventListener('keypress', handleCitySearch);
    elements.cityInput.addEventListener('input', handleInputChange);
    elements.searchBtn.addEventListener('click', handleSearchClick);
    
    // Location button
    elements.locationBtn.addEventListener('click', getCurrentLocation);
    
    // Mobile menu
    if (elements.menuBtn) {
        elements.menuBtn.addEventListener('click', toggleMobileMenu);
    }
    if (elements.closeMenu) {
        elements.closeMenu.addEventListener('click', closeMobileMenu);
    }
    if (elements.overlay) {
        elements.overlay.addEventListener('click', closeMobileMenu);
    }
    
    // Keyboard shortcuts
    document.addEventListener('keydown', handleKeyboardShortcuts);
    
    // Window resize handler
    window.addEventListener('resize', handleWindowResize);
    
    // Network status
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
}

/**
 * Event Handlers
 */
function handleCitySearch(e) {
    if (e.key === 'Enter') {
        const city = elements.cityInput.value.trim();
        if (city) {
            getWeatherByCity(city);
        }
    }
}

function handleInputChange(e) {
    // Enable search button when input has content
    const hasContent = e.target.value.trim().length > 0;
    elements.searchBtn.style.opacity = hasContent ? '1' : '0.6';
}

function handleSearchClick