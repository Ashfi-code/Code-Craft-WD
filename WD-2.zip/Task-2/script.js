class StopwatchApp {
    constructor() {
        this.startTime = 0;
        this.elapsedTime = 0;
        this.timerInterval = null;
        this.isRunning = false;
        this.lapTimes = [];
        this.lapStartTime = 0;
        this.soundEnabled = true;
        
        this.initializeElements();
        this.initializeEventListeners();
        this.createParticles();
        this.loadSettings();
        this.updateDisplay();
    }

    initializeElements() {
        // Time display elements
        this.timeDisplay = document.getElementById('time-display');
        this.millisecondsDisplay = document.getElementById('milliseconds-display');
        this.progressCircle = document.getElementById('progress-circle');
        
        // Control buttons
        this.startBtn = document.getElementById('start-btn');
        this.pauseBtn = document.getElementById('pause-btn');
        this.resetBtn = document.getElementById('reset-btn');
        this.lapBtn = document.getElementById('lap-btn');
        
        // Lap section elements
        this.lapSection = document.getElementById('lap-section');
        this.lapContainer = document.getElementById('lap-container');
        this.noLaps = document.getElementById('no-laps');
        this.lapStats = document.getElementById('lap-stats');
        this.bestLap = document.getElementById('best-lap');
        this.worstLap = document.getElementById('worst-lap');
        this.avgLap = document.getElementById('avg-lap');
        
        // Feature controls
        this.soundToggle = document.getElementById('sound-toggle');
        this.themeSelector = document.getElementById('theme-selector');
        
        // Audio elements
        this.startSound = document.getElementById('start-sound');
        this.stopSound = document.getElementById('stop-sound');
        this.lapSound = document.getElementById('lap-sound');
        
        // Progress circle properties
        this.progressRadius = 190;
        this.progressCircumference = 2 * Math.PI * this.progressRadius;
        this.progressCircle.style.strokeDasharray = this.progressCircumference;
        this.progressCircle.style.strokeDashoffset = this.progressCircumference;
    }

    initializeEventListeners() {
        // Control button events
        this.startBtn.addEventListener('click', () => this.start());
        this.pauseBtn.addEventListener('click', () => this.pause());
        this.resetBtn.addEventListener('click', () => this.reset());
        this.lapBtn.addEventListener('click', () => this.lap());
        
        // Feature control events
        this.soundToggle.addEventListener('change', () => this.toggleSound());
        this.themeSelector.addEventListener('change', () => this.changeTheme());
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => this.handleKeyboard(e));
        
        // Visibility change (pause when tab not visible)
        document.addEventListener('visibilitychange', () => this.handleVisibilityChange());
    }

    start() {
        if (!this.isRunning) {
            this.startTime = Date.now() - this.elapsedTime;
            this.lapStartTime = Date.now() - this.elapsedTime;
            this.timerInterval = setInterval(() => this.updateTimer(), 10);
            this.isRunning = true;
            this.updateButtons();
            this.playSound('start');
            document.body.classList.add('running');
        }
    }

    pause() {
        if (this.isRunning) {
            clearInterval(this.timerInterval);
            this.isRunning = false;
            this.updateButtons();
            this.playSound('stop');
            document.body.classList.remove('running');
        }
    }

    reset() {
        clearInterval(this.timerInterval);
        this.isRunning = false;
        this.elapsedTime = 0;
        this.startTime = 0;
        this.lapStartTime = 0;
        this.lapTimes = [];
        this.updateDisplay();
        this.updateButtons();
        this.updateLapDisplay();
        this.updateProgressRing(0);
        this.playSound('stop');
        document.body.classList.remove('running');
    }

    lap() {
        if (this.isRunning) {
            const currentTime = Date.now();
            const lapTime = currentTime - this.lapStartTime;
            const totalTime = this.elapsedTime;
            
            this.lapTimes.push({
                lapNumber: this.lapTimes.length + 1,
                lapTime: lapTime,
                totalTime: totalTime,
                timestamp: currentTime
            });
            
            this.lapStartTime = currentTime;
            this.updateLapDisplay();
            this.playSound('lap');
        }
    }

    updateTimer() {
        this.elapsedTime = Date.now() - this.startTime;
        this.updateDisplay();
        this.updateProgressRing(this.elapsedTime);
    }

    updateDisplay() {
        const time = this.formatTime(this.elapsedTime);
        this.timeDisplay.textContent = time.main;
        this.millisecondsDisplay.textContent = time.milliseconds;
    }

    updateProgressRing(elapsed) {
        // Create a visual progress that completes every minute
        const secondsInMinute = 60000; // 60 seconds in milliseconds
        const progress = (elapsed % secondsInMinute) / secondsInMinute;
        const offset = this.progressCircumference - (progress * this.progressCircumference);
        this.progressCircle.style.strokeDashoffset = offset;
    }

    formatTime(milliseconds) {
        const totalSeconds = Math.floor(milliseconds / 1000);
        const minutes = Math.floor(totalSeconds / 60);
        const seconds = totalSeconds % 60;
        const ms = Math.floor((milliseconds % 1000) / 10);

        return {
            main: `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}:${Math.floor(seconds/10)}${seconds%10}`,
            milliseconds: ms.toString().padStart(2, '0')
        };
    }

    updateButtons() {
        if (this.isRunning) {
            this.startBtn.disabled = true;
            this.pauseBtn.disabled = false;
            this.lapBtn.disabled = false;
            
            this.startBtn.querySelector('.btn-text').textContent = 'Running';
            this.startBtn.querySelector('.btn-icon').textContent = '🔄';
        } else {
            this.startBtn.disabled = false;
            this.pauseBtn.disabled = true;
            this.lapBtn.disabled = true;
            
            if (this.elapsedTime > 0) {
                this.startBtn.querySelector('.btn-text').textContent = 'Resume';
                this.startBtn.querySelector('.btn-icon').textContent = '▶️';
            } else {
                this.startBtn.querySelector('.btn-text').textContent = 'Start';
                this.startBtn.querySelector('.btn-icon').textContent = '▶️';
            }
        }
    }

    updateLapDisplay() {
        if (this.lapTimes.length === 0) {
            this.noLaps.style.display = 'block';
            this.lapStats.style.display = 'none';
            return;
        }

        this.noLaps.style.display = 'none';
        this.lapStats.style.display = 'grid';

        // Clear existing lap items
        const existingLaps = this.lapContainer.querySelectorAll('.lap-item');
        existingLaps.forEach(lap => lap.remove());

        // Calculate statistics
        const lapDurations = this.lapTimes.map(lap => lap.lapTime);
        const bestTime = Math.min(...lapDurations);
        const worstTime = Math.max(...lapDurations);
        const avgTime = lapDurations.reduce((a, b) => a + b, 0) / lapDurations.length;

        // Update statistics display
        this.bestLap.textContent = this.formatTime(bestTime).main;
        this.worstLap.textContent = this.formatTime(worstTime).main;
        this.avgLap.textContent = this.formatTime(avgTime).main;

        // Create lap items (show most recent first)
        const reversedLaps = [...this.lapTimes].reverse();
        reversedLaps.forEach((lap, index) => {
            const lapItem = this.createLapItem(lap, bestTime, worstTime);
            this.lapContainer.appendChild(lapItem);
        });
    }

    createLapItem(lap, bestTime, worstTime) {
        const lapItem = document.createElement('div');
        lapItem.className = 'lap-item';

        // Add special classes for best/worst laps
        if (lap.lapTime === bestTime) {
            lapItem.classList.add('best-lap');
        }
        if (lap.lapTime === worstTime) {
            lapItem.classList.add('worst-lap');
        }

        // Calculate difference from average
        const avgTime = this.lapTimes.reduce((sum, l) => sum + l.lapTime, 0) / this.lapTimes.length;
        const difference = lap.lapTime - avgTime;

        lapItem.innerHTML = `
            <div class="lap-number">Lap ${lap.lapNumber}</div>
            <div class="lap-time">${this.formatTime(lap.lapTime).main}</div>
            <div class="lap-difference ${difference >= 0 ? 'positive' : 'negative'}">
                ${difference >= 0 ? '+' : ''}${this.formatTime(Math.abs(difference)).main}
            </div>
        `;

        return lapItem;
    }

    handleKeyboard(e) {
        // Prevent default if we're handling the key
        if (['Space', 'KeyR', 'KeyL', 'KeyP'].includes(e.code)) {
            e.preventDefault();
        }

        switch (e.code) {
            case 'Space':
                if (this.isRunning) {
                    this.pause();
                } else {
                    this.start();
                }
                break;
            case 'KeyR':
                this.reset();
                break;
            case 'KeyL':
                if (this.isRunning) {
                    this.lap();
                }
                break;
            case 'KeyP':
                if (this.isRunning) {
                    this.pause();
                }
                break;
        }
    }

    handleVisibilityChange() {
        if (document.visibilityState === 'hidden' && this.isRunning) {
            // Store the time when tab becomes hidden
            this.hiddenTime = Date.now();
        } else if (document.visibilityState === 'visible' && this.hiddenTime && this.isRunning) {
            // Adjust start time to account for time spent in background
            const timeDiff = Date.now() - this.hiddenTime;
            this.startTime += timeDiff;
            this.hiddenTime = null;
        }
    }

    playSound(type) {
        if (!this.soundEnabled) return;

        let audio;
        switch (type) {
            case 'start':
                audio = this.startSound;
                break;
            case 'stop':
                audio = this.stopSound;
                break;
            case 'lap':
                audio = this.lapSound;
                break;
        }

        if (audio) {
            audio.currentTime = 0;
            audio.play().catch(e => {
                console.log('Audio play failed:', e);
            });
        }
    }

    toggleSound() {
        this.soundEnabled = this.soundToggle.checked;
        this.saveSettings();
    }

    changeTheme() {
        const theme = this.themeSelector.value;
        document.documentElement.setAttribute('data-theme', theme);
        this.saveSettings();
    }

    createParticles() {
        const particlesContainer = document.getElementById('particles-container');
        const particleCount = 20;

        for (let i = 0; i < particleCount; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            
            // Random positioning
            particle.style.left = Math.random() * 100 + '%';
            particle.style.top = Math.random() * 100 + '%';
            
            // Random animation delay
            particle.style.animationDelay = Math.random() * 8 + 's';
            particle.style.animationDuration = (8 + Math.random() * 4) + 's';
            
            particlesContainer.appendChild(particle);
        }
    }

    saveSettings() {
        const settings = {
            soundEnabled: this.soundEnabled,
            theme: this.themeSelector.value
        };
        
        // Save to memory (localStorage not available in Claude.ai)
        this.settings = settings;
    }

    loadSettings() {
        // Load from memory (would be localStorage in real environment)
        const settings = this.settings || {
            soundEnabled: true,
            theme: 'default'
        };

        this.soundEnabled = settings.soundEnabled;
        this.soundToggle.checked = this.soundEnabled;
        
        this.themeSelector.value = settings.theme;
        document.documentElement.setAttribute('data-theme', settings.theme);
    }

    // Utility method for exporting lap data
    exportLapData() {
        if (this.lapTimes.length === 0) {
            alert('No lap data to export');
            return;
        }

        const data = {
            totalTime: this.formatTime(this.elapsedTime).main,
            lapCount: this.lapTimes.length,
            laps: this.lapTimes.map(lap => ({
                lapNumber: lap.lapNumber,
                lapTime: this.formatTime(lap.lapTime).main,
                totalTime: this.formatTime(lap.totalTime).main
            })),
            exportDate: new Date().toISOString()
        };

        console.log('Lap Data Export:', JSON.stringify(data, null, 2));
        
        // Create downloadable file content
        const content = JSON.stringify(data, null, 2);
        const blob = new Blob([content], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        // Create temporary download link
        const a = document.createElement('a');
        a.href = url;
        a.download = `stopwatch-data-${Date.now()}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    // Method to handle precision timing for competitive use
    getPreciseTime() {
        return performance.now() + performance.timeOrigin;
    }
}

// Initialize the stopwatch when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const stopwatch = new StopwatchApp();
    
    // Make stopwatch globally available for debugging
    window.stopwatch = stopwatch;
    
    // Add export functionality to reset button (long press)
    let resetPressTimer;
    
    stopwatch.resetBtn.addEventListener('mousedown', () => {
        resetPressTimer = setTimeout(() => {
            if (confirm('Export lap data?')) {
                stopwatch.exportLapData();
            }
        }, 2000);
    });
    
    stopwatch.resetBtn.addEventListener('mouseup', () => {
        clearTimeout(resetPressTimer);
    });
    
    stopwatch.resetBtn.addEventListener('mouseleave', () => {
        clearTimeout(resetPressTimer);
    });
    
    // Add touch support for mobile
    let touchStartTime = 0;
    
    stopwatch.resetBtn.addEventListener('touchstart', () => {
        touchStartTime = Date.now();
        resetPressTimer = setTimeout(() => {
            if (confirm('Export lap data?')) {
                stopwatch.exportLapData();
            }
        }, 2000);
    });
    
    stopwatch.resetBtn.addEventListener('touchend', () => {
        const touchDuration = Date.now() - touchStartTime;
        if (touchDuration < 2000) {
            clearTimeout(resetPressTimer);
        }
    });
    
    console.log('🏁 Stopwatch Application Initialized');
    console.log('⌨️  Keyboard Shortcuts:');
    console.log('   Space: Start/Pause');
    console.log('   R: Reset');
    console.log('   L: Lap (when running)');
    console.log('   P: Pause');
    console.log('🔧 Hold Reset button for 2 seconds to export lap data');
});

// Handle page unload to save state
window.addEventListener('beforeunload', () => {
    if (window.stopwatch) {
        window.stopwatch.saveSettings();
    }
});

// Performance monitoring
if (typeof performance !== 'undefined' && performance.mark) {
    performance.mark('stopwatch-app-loaded');
}