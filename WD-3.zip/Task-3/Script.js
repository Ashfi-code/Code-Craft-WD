// Game state variables
let board = ['', '', '', '', '', '', '', '', ''];
let currentPlayer = 'X';
let gameActive = true;
let isAIMode = false;
let scores = {
    X: 0,
    O: 0,
    ties: 0
};

// DOM elements
const cells = document.querySelectorAll('.cell');
const currentPlayerDisplay = document.getElementById('current-player');
const gameStatus = document.getElementById('game-status');
const resetGameBtn = document.getElementById('reset-game');
const resetScoreBtn = document.getElementById('reset-score');
const aiToggleBtn = document.getElementById('ai-toggle');
const scoreX = document.getElementById('score-x');
const scoreO = document.getElementById('score-o');
const scoreTies = document.getElementById('score-ties');

// Winning combinations
const winningConditions = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
];

// Initialize game
function initGame() {
    cells.forEach((cell, index) => {
        cell.addEventListener('click', () => handleCellClick(index));
    });
    
    resetGameBtn.addEventListener('click', resetGame);
    resetScoreBtn.addEventListener('click', resetScore);
    aiToggleBtn.addEventListener('click', toggleAI);
    
    updateDisplay();
}

// Handle cell click
function handleCellClick(index) {
    if (board[index] !== '' || !gameActive) return;
    
    makeMove(index, currentPlayer);
    
    if (gameActive && isAIMode && currentPlayer === 'O') {
        setTimeout(() => {
            makeAIMove();
        }, 500);
    }
}

// Make a move
function makeMove(index, player) {
    board[index] = player;
    cells[index].textContent = player;
    cells[index].classList.add(player.toLowerCase());
    
    if (checkWinner()) {
        handleGameEnd();
    } else if (board.every(cell => cell !== '')) {
        handleTie();
    } else {
        switchPlayer();
    }
    
    updateDisplay();
}

// Check for winner
function checkWinner() {
    for (let condition of winningConditions) {
        const [a, b, c] = condition;
        if (board[a] && board[a] === board[b] && board[a] === board[c]) {
            // Highlight winning cells
            cells[a].classList.add('winning');
            cells[b].classList.add('winning');
            cells[c].classList.add('winning');
            return true;
        }
    }
    return false;
}

// Handle game end (winner)
function handleGameEnd() {
    gameActive = false;
    scores[currentPlayer]++;
    gameStatus.textContent = `Player ${currentPlayer} wins!`;
    gameStatus.className = 'game-status winner';
    updateScoreDisplay();
}

// Handle tie game
function handleTie() {
    gameActive = false;
    scores.ties++;
    gameStatus.textContent = "It's a tie!";
    gameStatus.className = 'game-status tie';
    updateScoreDisplay();
}

// Switch current player
function switchPlayer() {
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
}

// AI move logic
function makeAIMove() {
    if (!gameActive) return;
    
    let bestMove = getBestMove();
    makeMove(bestMove, 'O');
}

// Get best move for AI (minimax algorithm)
function getBestMove() {
    // First, try to win
    for (let i = 0; i < board.length; i++) {
        if (board[i] === '') {
            board[i] = 'O';
            if (checkWinningMove('O')) {
                board[i] = '';
                return i;
            }
            board[i] = '';
        }
    }
    
    // Then, try to block player from winning
    for (let i = 0; i < board.length; i++) {
        if (board[i] === '') {
            board[i] = 'X';
            if (checkWinningMove('X')) {
                board[i] = '';
                return i;
            }
            board[i] = '';
        }
    }
    
    // Take center if available
    if (board[4] === '') return 4;
    
    // Take corners
    const corners = [0, 2, 6, 8];
    const availableCorners = corners.filter(i => board[i] === '');
    if (availableCorners.length > 0) {
        return availableCorners[Math.floor(Math.random() * availableCorners.length)];
    }
    
    // Take any available space
    const availableMoves = board.map((cell, index) => cell === '' ? index : null).filter(val => val !== null);
    return availableMoves[Math.floor(Math.random() * availableMoves.length)];
}

// Check if a move would result in a win
function checkWinningMove(player) {
    for (let condition of winningConditions) {
        const [a, b, c] = condition;
        if (board[a] === player && board[b] === player && board[c] === player) {
            return true;
        }
    }
    return false;
}

// Reset game
function resetGame() {
    board = ['', '', '', '', '', '', '', '', ''];
    currentPlayer = 'X';
    gameActive = true;
    
    cells.forEach(cell => {
        cell.textContent = '';
        cell.className = 'cell';
    });
    
    gameStatus.textContent = 'Make your move!';
    gameStatus.className = 'game-status';
    updateDisplay();
}

// Reset score
function resetScore() {
    scores = { X: 0, O: 0, ties: 0 };
    updateScoreDisplay();
}

// Toggle AI mode
function toggleAI() {
    isAIMode = !isAIMode;
    aiToggleBtn.textContent = isAIMode ? 'Play vs Human' : 'Play vs AI';
    aiToggleBtn.classList.toggle('active');
    resetGame();
    
    if (isAIMode) {
        gameStatus.textContent = 'Playing against AI! You are X.';
    } else {
        gameStatus.textContent = 'Playing against another player!';
    }
}

// Update display
function updateDisplay() {
    currentPlayerDisplay.textContent = currentPlayer;
    currentPlayerDisplay.style.color = currentPlayer === 'X' ? '#e74c3c' : '#3498db';
}

// Update score display
function updateScoreDisplay() {
    scoreX.textContent = scores.X;
    scoreO.textContent = scores.O;
    scoreTies.textContent = scores.ties;
}

// Initialize the game when the page loads
document.addEventListener('DOMContentLoaded', initGame);